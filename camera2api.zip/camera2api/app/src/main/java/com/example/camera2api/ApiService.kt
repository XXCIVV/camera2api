package com.example.camera2api
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part


data class Detection(
    val label: String,
    val confidence: Float,
    val bbox: List<Float>
)

data class DetectionResponse(
    val detections: List<Detection>,
    val image: String  // Processed image in hex format
)

interface ApiService {
    @Multipart
    @POST("/detect/")
    fun detectObjects(@Part file: MultipartBody.Part): Call<DetectionResponse>
}