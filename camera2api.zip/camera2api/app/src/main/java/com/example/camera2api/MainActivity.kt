package com.example.camera2api

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var imageView: ImageView
    private lateinit var selectButton: Button
    private lateinit var processButton: Button
    private var selectedFile: File? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        selectButton = findViewById(R.id.selectButton)
        processButton = findViewById(R.id.processButton)

        selectButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "image/*"
            startActivityForResult(intent, 100)
        }

        processButton.setOnClickListener {
            selectedFile?.let { file -> uploadImage(file) }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK && data != null) {
            val inputStream = contentResolver.openInputStream(data.data!!)
            val file = File(cacheDir, "selected.jpg")
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            outputStream.close()
            selectedFile = file
            imageView.setImageBitmap(BitmapFactory.decodeFile(file.path))
        }
    }

    private fun uploadImage(file: File) {
        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), file)
        val body = MultipartBody.Part.createFormData("file", file.name, requestFile)

        RetrofitClient.instance.detectObjects(body).enqueue(object : Callback<DetectionResponse> {
            override fun onResponse(call: Call<DetectionResponse>, response: Response<DetectionResponse>) {
                if (response.isSuccessful) {
                    val detectionResponse = response.body()

                    // Convert Hex to Bitmap
                    val imageData = detectionResponse?.image ?: ""
                    val bytes = hexToBytes(imageData)
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

                    // Show processed image
                    imageView.setImageBitmap(bitmap)
                }
            }

            override fun onFailure(call: Call<DetectionResponse>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }

    private fun hexToBytes(hexString: String): ByteArray {
        return hexString.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }
}
